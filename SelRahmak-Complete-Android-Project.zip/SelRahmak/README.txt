# Sel Rahmak - Smart Kinship Reminder App

## Overview
Sel Rahmak is a native Android application built with Kotlin that helps users maintain relationships with their loved ones through intelligent reminder systems.

## Features
✅ Native Android (Kotlin)
✅ Contacts Integration (ContactsContract API)
✅ Custom Categories with Custom Intervals
✅ Reminder System with WorkManager
✅ Points System
✅ WhatsApp Integration
✅ One-tap Calling
✅ Simple & Advanced UI Modes
✅ Material 3 Design
✅ Arabic RTL Support
✅ Offline Functionality
✅ Optional Firebase Sync
✅ Google Play Compliant

## System Requirements
- Android Studio Hedgehog (2023.1.1) or later
- Minimum SDK: Android 10 (API 29)
- Target SDK: Android 14 (API 34)
- Java 17
- Kotlin 1.9.20

## How to Open Project in Android Studio

### Step 1: Extract the ZIP
Extract the SelRahmak.zip file to a location on your computer.

### Step 2: Open in Android Studio
1. Open Android Studio
2. Click "Open" or "File > Open"
3. Navigate to the extracted SelRahmak folder
4. Click "OK"
5. Wait for Gradle sync to complete

### Step 3: Sync Gradle
If Gradle doesn't sync automatically:
1. Click "File > Sync Project with Gradle Files"
2. Wait for the sync to complete

## How to Build APK/AAB

### Build Debug APK (For Testing)
1. In Android Studio, click "Build > Build Bundle(s) / APK(s) > Build APK(s)"
2. Wait for the build to complete
3. Click "locate" in the notification to find the APK
4. APK will be at: `app/build/outputs/apk/debug/app-debug.apk`

### Build Release APK (For Distribution)
1. Click "Build > Build Bundle(s) / APK(s) > Build APK(s)"
2. The APK will be signed with debug keystore by default
3. For production, you need to create your own keystore

### Build AAB (For Google Play)
1. Click "Build > Build Bundle(s) / APK(s) > Build Bundle(s)"
2. The AAB will be at: `app/build/outputs/bundle/release/app-release.aab`

## Creating Production Keystore

### Generate Keystore:
```bash
keytool -genkey -v -keystore selrahmak-release.keystore -alias selrahmak -keyalg RSA -keysize 2048 -validity 10000
```

### Configure build.gradle.kts:
Add to `app/build.gradle.kts`:

```kotlin
android {
    signingConfigs {
        create("release") {
            storeFile = file("path/to/selrahmak-release.keystore")
            storePassword = "your_store_password"
            keyAlias = "selrahmak"
            keyPassword = "your_key_password"
        }
    }
    
    buildTypes {
        release {
            signingConfig = signingConfigs.getByName("release")
        }
    }
}
```

## Firebase Setup (Optional)

### If you want to use Firebase features:

1. Go to https://console.firebase.google.com
2. Create a new project or use existing
3. Add Android app with package name: `com.selrahmak.app`
4. Download `google-services.json`
5. Replace the existing `app/google-services.json` with your file

### Firebase Features:
- Authentication (Sign in with Google)
- Firestore (Sync data across devices)
- Cloud Messaging (Optional)

## Running on Device/Emulator

### On Physical Device:
1. Enable Developer Options on your Android device
2. Enable USB Debugging
3. Connect device via USB
4. Click "Run" in Android Studio
5. Select your device

### On Emulator:
1. Open AVD Manager (Tools > Device Manager)
2. Create a new virtual device (API 29+)
3. Click "Run" in Android Studio
4. Select the emulator

## Installing APK on Device

### Via USB (ADB):
```bash
adb install app/build/outputs/apk/debug/app-debug.apk
```

### Via File Transfer:
1. Copy APK to device
2. Open file manager on device
3. Tap APK file
4. Allow "Install from Unknown Sources" if prompted
5. Click "Install"

## Permissions Required

The app requests the following permissions:
- READ_CONTACTS - To import device contacts
- WRITE_CONTACTS - To delete contacts (Advanced Mode)
- CALL_PHONE - To make phone calls
- POST_NOTIFICATIONS - To send reminders (Android 13+)
- INTERNET - For Firebase sync (optional)

All permissions are requested with proper explanations as per Google Play policy.

## Project Structure

```
SelRahmak/
├── app/
│   ├── src/
│   │   ├── main/
│   │   │   ├── java/com/selrahmak/app/
│   │   │   │   ├── data/
│   │   │   │   │   ├── database/      # Room entities and DAOs
│   │   │   │   │   ├── repository/    # Data repositories
│   │   │   │   │   └── workers/       # WorkManager & notifications
│   │   │   │   ├── domain/
│   │   │   │   │   └── usecase/       # Business logic
│   │   │   │   ├── presentation/
│   │   │   │   │   ├── screens/       # Compose UI screens
│   │   │   │   │   ├── theme/         # Material 3 theme
│   │   │   │   │   ├── viewmodel/     # ViewModels
│   │   │   │   │   └── MainActivity.kt
│   │   │   │   └── util/              # Utilities
│   │   │   ├── res/
│   │   │   │   ├── values/            # English strings
│   │   │   │   ├── values-ar/         # Arabic strings
│   │   │   │   └── ...
│   │   │   └── AndroidManifest.xml
│   │   └── ...
│   ├── build.gradle.kts
│   └── google-services.json
├── build.gradle.kts
├── settings.gradle.kts
└── README.txt
```

## Default Categories

The app comes with 9 pre-configured categories:
1. Parent (الوالد / الوالدة) - 1 day
2. Sibling (الأخ / الأخت) - 3 days
3. Uncle/Aunt (العم / العمة) - 7 days
4. Distant Uncle/Aunt (العم / العمة البعيدين) - 30 days
5. Close Friend (الصديق المقرب) - 5 days
6. Distant Friend (الصديق البعيد) - 14 days
7. Colleague (الزميل) - 7 days
8. Distant Colleague (الزميل البعيد) - 21 days
9. Cousin (ابن العم / ابنة العم) - 10 days

Users can also create unlimited custom categories with custom intervals.

## Testing the App

### Test Contacts Integration:
1. Grant contacts permission when prompted
2. Click "Import Contacts" button
3. Contacts will appear in "All Contacts"

### Test Category Assignment:
1. Select a contact
2. Choose a category
3. Contact becomes active in reminder system

### Test Reminders:
1. Reminders run every 15 minutes in background
2. Check notification panel for reminders
3. Tap notification to open app

### Test WhatsApp:
1. Add a contact with phone number
2. Click WhatsApp button
3. Default message pre-filled
4. WhatsApp opens ready to send

## Troubleshooting

### Gradle Sync Failed:
- Check internet connection
- File > Invalidate Caches / Restart
- Update Android Studio to latest version

### Build Failed:
- Clean project: Build > Clean Project
- Rebuild: Build > Rebuild Project
- Check Java version (must be 17)

### APK Won't Install:
- Enable "Install Unknown Apps" permission
- Check minimum SDK requirement (API 29)
- Uninstall old version if exists

### Permissions Not Working:
- Go to App Settings
- Grant all required permissions manually
- Restart app

## Google Play Submission Checklist

✅ App uses proper permission explanations
✅ Privacy policy included (update with your link)
✅ No hidden data collection
✅ Complies with User Data policy
✅ ProGuard rules configured
✅ Signed with release keystore
✅ AAB generated
✅ Screenshots prepared (phone & tablet)
✅ App description written
✅ Categories selected

## Support

For issues or questions:
- Check this README
- Review code comments
- Android Developer Documentation: https://developer.android.com

## Version History

### Version 1.0 (Current)
- Initial release
- All core features implemented
- Google Play ready

## License

This project is provided as-is for educational and commercial use.

## Credits

Built with:
- Kotlin
- Jetpack Compose
- Room Database
- WorkManager
- Material 3
- Firebase (optional)

---

**Note**: Before publishing to Google Play, make sure to:
1. Create production keystore
2. Set up proper Firebase project
3. Write privacy policy
4. Update app icon
5. Test on multiple devices
6. Review Google Play policies
