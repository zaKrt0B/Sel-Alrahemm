package com.selrahmak.app.data.workers

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        // Handle reminder actions from notification
        when (intent.action) {
            "com.selrahmak.app.REMINDER_ACTION" -> {
                // Handle reminder notification action
            }
        }
    }
}
