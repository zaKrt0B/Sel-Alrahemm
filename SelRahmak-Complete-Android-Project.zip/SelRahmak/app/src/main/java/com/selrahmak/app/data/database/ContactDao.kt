package com.selrahmak.app.data.database

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ContactDao {
    
    @Query("SELECT * FROM contacts WHERE isActive = 1 ORDER BY name ASC")
    fun getAllContacts(): Flow<List<ContactEntity>>
    
    @Query("SELECT * FROM contacts WHERE categoryId IS NULL AND isActive = 1 ORDER BY name ASC")
    fun getUncategorizedContacts(): Flow<List<ContactEntity>>
    
    @Query("SELECT * FROM contacts WHERE categoryId = :categoryId AND isActive = 1 ORDER BY name ASC")
    fun getContactsByCategory(categoryId: String): Flow<List<ContactEntity>>
    
    @Query("SELECT * FROM contacts WHERE delayDays > 0 AND isActive = 1 ORDER BY delayDays DESC, nextReminderDate ASC")
    fun getDelayedContacts(): Flow<List<ContactEntity>>
    
    @Query("SELECT * FROM contacts WHERE nextReminderDate <= :currentTime AND isActive = 1 ORDER BY nextReminderDate ASC")
    fun getContactsDueForReminder(currentTime: Long): Flow<List<ContactEntity>>
    
    @Query("SELECT * FROM contacts WHERE contactId = :contactId")
    suspend fun getContactById(contactId: String): ContactEntity?
    
    @Query("SELECT * FROM contacts WHERE contactId = :contactId")
    fun getContactByIdFlow(contactId: String): Flow<ContactEntity?>
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertContact(contact: ContactEntity)
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertContacts(contacts: List<ContactEntity>)
    
    @Update
    suspend fun updateContact(contact: ContactEntity)
    
    @Delete
    suspend fun deleteContact(contact: ContactEntity)
    
    @Query("UPDATE contacts SET isActive = 0 WHERE contactId = :contactId")
    suspend fun deactivateContact(contactId: String)
    
    @Query("UPDATE contacts SET lastContactedDate = :date, nextReminderDate = :nextDate, delayDays = 0, consecutiveContacts = consecutiveContacts + 1, updatedAt = :updateTime WHERE contactId = :contactId")
    suspend fun markAsContacted(contactId: String, date: Long, nextDate: Long, updateTime: Long)
    
    @Query("UPDATE contacts SET delayDays = :days, updatedAt = :updateTime WHERE contactId = :contactId")
    suspend fun updateDelayDays(contactId: String, days: Int, updateTime: Long)
    
    @Query("UPDATE contacts SET pointsEarned = pointsEarned + :points, updatedAt = :updateTime WHERE contactId = :contactId")
    suspend fun addPoints(contactId: String, points: Int, updateTime: Long)
    
    @Query("UPDATE contacts SET pointsLost = pointsLost + :points, updatedAt = :updateTime WHERE contactId = :contactId")
    suspend fun subtractPoints(contactId: String, points: Int, updateTime: Long)
    
    @Query("SELECT SUM(pointsEarned - pointsLost) FROM contacts WHERE isActive = 1")
    fun getTotalPoints(): Flow<Int?>
    
    @Query("SELECT COUNT(*) FROM contacts WHERE isActive = 1")
    fun getActiveContactCount(): Flow<Int>
    
    @Query("SELECT COUNT(*) FROM contacts WHERE delayDays > 0 AND isActive = 1")
    fun getDelayedContactCount(): Flow<Int>
}
