package com.selrahmak.app.data.database

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(tableName = "reminder_history")
data class ReminderHistoryEntity(
    @PrimaryKey
    val historyId: String = UUID.randomUUID().toString(),
    val contactId: String,
    val reminderDate: Long,
    val actionTaken: String, // "called", "whatsapp", "snoozed", "ignored"
    val pointsEarned: Int = 0,
    val createdAt: Long = System.currentTimeMillis()
)
