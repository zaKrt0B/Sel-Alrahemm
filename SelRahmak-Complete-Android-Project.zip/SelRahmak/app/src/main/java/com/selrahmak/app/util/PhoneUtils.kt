package com.selrahmak.app.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import java.net.URLEncoder

object PhoneUtils {
    
    fun makePhoneCall(context: Context, phoneNumber: String?) {
        if (phoneNumber.isNullOrBlank()) {
            Toast.makeText(context, "No phone number available", Toast.LENGTH_SHORT).show()
            return
        }
        
        try {
            val intent = Intent(Intent.ACTION_DIAL).apply {
                data = Uri.parse("tel:${phoneNumber.replace(" ", "")}")
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(context, "Could not make call", Toast.LENGTH_SHORT).show()
        }
    }
    
    fun sendWhatsAppMessage(context: Context, phoneNumber: String?, message: String) {
        if (phoneNumber.isNullOrBlank()) {
            Toast.makeText(context, "No phone number available", Toast.LENGTH_SHORT).show()
            return
        }
        
        try {
            // Clean phone number (remove spaces, dashes, etc.)
            val cleanNumber = phoneNumber.replace(Regex("[^0-9+]"), "")
            
            // Ensure number has country code
            val formattedNumber = if (cleanNumber.startsWith("+")) {
                cleanNumber.substring(1) // Remove the + for WhatsApp API
            } else if (cleanNumber.startsWith("00")) {
                cleanNumber.substring(2)
            } else {
                "966$cleanNumber" // Default to Saudi Arabia if no country code
            }
            
            val encodedMessage = URLEncoder.encode(message, "UTF-8")
            val url = "https://api.whatsapp.com/send?phone=$formattedNumber&text=$encodedMessage"
            
            val intent = Intent(Intent.ACTION_VIEW).apply {
                data = Uri.parse(url)
                setPackage("com.whatsapp")
            }
            
            context.startActivity(intent)
        } catch (e: Exception) {
            // If WhatsApp is not installed, try opening in browser
            try {
                val cleanNumber = phoneNumber.replace(Regex("[^0-9+]"), "")
                val formattedNumber = if (cleanNumber.startsWith("+")) {
                    cleanNumber.substring(1)
                } else {
                    "966$cleanNumber"
                }
                
                val encodedMessage = URLEncoder.encode(message, "UTF-8")
                val url = "https://api.whatsapp.com/send?phone=$formattedNumber&text=$encodedMessage"
                
                val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                context.startActivity(browserIntent)
            } catch (e2: Exception) {
                Toast.makeText(context, "WhatsApp not installed", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
