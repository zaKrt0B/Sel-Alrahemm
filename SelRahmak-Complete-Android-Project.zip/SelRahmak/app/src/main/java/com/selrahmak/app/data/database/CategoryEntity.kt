package com.selrahmak.app.data.database

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(tableName = "categories")
data class CategoryEntity(
    @PrimaryKey
    val categoryId: String = UUID.randomUUID().toString(),
    val nameEn: String,
    val nameAr: String,
    val defaultIntervalDays: Int,
    val isCustom: Boolean = false,
    val isActive: Boolean = true,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)
