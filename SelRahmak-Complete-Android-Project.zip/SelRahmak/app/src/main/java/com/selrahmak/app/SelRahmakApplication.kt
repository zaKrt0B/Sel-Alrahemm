package com.selrahmak.app

import android.app.Application
import com.selrahmak.app.data.database.AppDatabase

class SelRahmakApplication : Application() {
    
    val database: AppDatabase by lazy { AppDatabase.getDatabase(this) }
    
    override fun onCreate() {
        super.onCreate()
        // Any app-level initialization
    }
}
