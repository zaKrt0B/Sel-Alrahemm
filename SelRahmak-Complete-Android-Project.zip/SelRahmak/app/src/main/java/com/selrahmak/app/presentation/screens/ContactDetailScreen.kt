package com.selrahmak.app.presentation.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.selrahmak.app.R
import com.selrahmak.app.presentation.viewmodel.CategoryViewModel
import com.selrahmak.app.presentation.viewmodel.MainViewModel
import com.selrahmak.app.util.DateUtils
import com.selrahmak.app.util.PhoneUtils

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ContactDetailScreen(
    viewModel: MainViewModel,
    categoryViewModel: CategoryViewModel,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val contact by viewModel.selectedContact.collectAsState()
    val allCategories by categoryViewModel.allCategories.collectAsState()
    
    var showDeleteDialog by remember { mutableStateOf(false) }
    var showCategoryDialog by remember { mutableStateOf(false) }
    
    contact?.let { currentContact ->
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text(currentContact.name) },
                    navigationIcon = {
                        IconButton(onClick = onNavigateBack) {
                            Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        titleContentColor = MaterialTheme.colorScheme.onPrimary
                    )
                )
            }
        ) { paddingValues ->
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item {
                    Card {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = stringResource(R.string.contact_details),
                                style = MaterialTheme.typography.titleMedium
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            currentContact.phoneNumber?.let {
                                Text("Phone: $it")
                            }
                            Text("Last Contacted: ${DateUtils.formatDate(currentContact.lastContactedDate)}")
                            Text("Next Reminder: ${DateUtils.formatDate(currentContact.nextReminderDate)}")
                        }
                    }
                }
                
                item {
                    Card {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Button(
                                onClick = { showCategoryDialog = true },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(stringResource(R.string.select_category))
                            }
                        }
                    }
                }
                
                item {
                    Card {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Button(
                                onClick = {
                                    PhoneUtils.makePhoneCall(context, currentContact.phoneNumber)
                                },
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = MaterialTheme.colorScheme.primary
                                )
                            ) {
                                Icon(Icons.Default.Phone, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(stringResource(R.string.call_now))
                            }
                        }
                    }
                }
                
                item {
                    Card {
                        Column(modifier = Modifier.padding(16.dp)) {
                            OutlinedButton(
                                onClick = { viewModel.deactivateContact(currentContact.contactId) },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(stringResource(R.string.remove_from_system))
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            OutlinedButton(
                                onClick = { showDeleteDialog = true },
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    contentColor = MaterialTheme.colorScheme.error
                                )
                            ) {
                                Text(stringResource(R.string.delete_from_device))
                            }
                        }
                    }
                }
            }
        }
        
        if (showCategoryDialog) {
            AlertDialog(
                onDismissRequest = { showCategoryDialog = false },
                title = { Text(stringResource(R.string.select_category)) },
                text = {
                    LazyColumn {
                        items(allCategories) { category ->
                            TextButton(
                                onClick = {
                                    val updatedContact = currentContact.copy(
                                        categoryId = category.categoryId,
                                        isActive = true
                                    )
                                    viewModel.updateContact(updatedContact)
                                    showCategoryDialog = false
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(category.nameAr)
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = { showCategoryDialog = false }) {
                        Text(stringResource(R.string.cancel))
                    }
                }
            )
        }
        
        if (showDeleteDialog) {
            AlertDialog(
                onDismissRequest = { showDeleteDialog = false },
                title = { Text(stringResource(R.string.confirm_delete)) },
                text = { Text("This will permanently delete the contact from your device.") },
                confirmButton = {
                    Button(
                        onClick = {
                            viewModel.deleteContactFromDevice(currentContact.contactId)
                            showDeleteDialog = false
                            onNavigateBack()
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.error
                        )
                    ) {
                        Text(stringResource(R.string.yes))
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showDeleteDialog = false }) {
                        Text(stringResource(R.string.no))
                    }
                }
            )
        }
    }
}
