package com.selrahmak.app.presentation

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.selrahmak.app.R
import com.selrahmak.app.data.database.AppDatabase
import com.selrahmak.app.data.repository.CategoryRepository
import com.selrahmak.app.data.repository.ContactRepository
import com.selrahmak.app.data.workers.ReminderWorker
import com.selrahmak.app.presentation.screens.*
import com.selrahmak.app.presentation.theme.SelRahmakTheme
import com.selrahmak.app.presentation.viewmodel.CategoryViewModel
import com.selrahmak.app.presentation.viewmodel.MainViewModel
import com.selrahmak.app.presentation.viewmodel.SettingsViewModel
import com.selrahmak.app.util.UserPreferences
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    
    private lateinit var mainViewModel: MainViewModel
    private lateinit var categoryViewModel: CategoryViewModel
    private lateinit var settingsViewModel: SettingsViewModel
    
    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        // Handle permission results
    }
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Initialize ViewModels
        val database = AppDatabase.getDatabase(this)
        val contactRepository = ContactRepository(
            database.contactDao(),
            database.reminderHistoryDao(),
            this
        )
        val categoryRepository = CategoryRepository(database.categoryDao())
        val userPreferences = UserPreferences(this)
        
        mainViewModel = MainViewModel(contactRepository, userPreferences)
        categoryViewModel = CategoryViewModel(categoryRepository)
        settingsViewModel = SettingsViewModel(userPreferences)
        
        // Schedule background work
        ReminderWorker.schedule(this)
        
        // Initialize default categories
        categoryViewModel.initializeDefaultCategories()
        
        // Request permissions
        checkAndRequestPermissions()
        
        setContent {
            val language by settingsViewModel.language.collectAsState()
            val isRtl = language == "ar"
            
            SelRahmakTheme(isRtl = isRtl) {
                MainApp(
                    mainViewModel = mainViewModel,
                    categoryViewModel = categoryViewModel,
                    settingsViewModel = settingsViewModel
                )
            }
        }
    }
    
    private fun checkAndRequestPermissions() {
        val permissionsToRequest = mutableListOf<String>()
        
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            permissionsToRequest.add(Manifest.permission.READ_CONTACTS)
        }
        
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE)
            != PackageManager.PERMISSION_GRANTED
        ) {
            permissionsToRequest.add(Manifest.permission.CALL_PHONE)
        }
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                permissionsToRequest.add(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
        
        if (permissionsToRequest.isNotEmpty()) {
            requestPermissionLauncher.launch(permissionsToRequest.toTypedArray())
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainApp(
    mainViewModel: MainViewModel,
    categoryViewModel: CategoryViewModel,
    settingsViewModel: SettingsViewModel
) {
    val navController = rememberNavController()
    val currentBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = currentBackStackEntry?.destination?.route
    
    val isSimpleMode by settingsViewModel.isSimpleMode.collectAsState()
    
    Scaffold(
        bottomBar = {
            if (currentRoute in listOf("home", "contacts", "categories", "settings")) {
                NavigationBar {
                    NavigationBarItem(
                        icon = { Icon(Icons.Default.Home, contentDescription = null) },
                        label = { Text(stringResource(R.string.nav_home)) },
                        selected = currentRoute == "home",
                        onClick = { navController.navigate("home") { popUpTo("home") { inclusive = true } } }
                    )
                    NavigationBarItem(
                        icon = { Icon(Icons.Default.Person, contentDescription = null) },
                        label = { Text(stringResource(R.string.nav_contacts)) },
                        selected = currentRoute == "contacts",
                        onClick = { navController.navigate("contacts") }
                    )
                    if (!isSimpleMode) {
                        NavigationBarItem(
                            icon = { Icon(Icons.Default.List, contentDescription = null) },
                            label = { Text(stringResource(R.string.nav_categories)) },
                            selected = currentRoute == "categories",
                            onClick = { navController.navigate("categories") }
                        )
                    }
                    NavigationBarItem(
                        icon = { Icon(Icons.Default.Settings, contentDescription = null) },
                        label = { Text(stringResource(R.string.nav_settings)) },
                        selected = currentRoute == "settings",
                        onClick = { navController.navigate("settings") }
                    )
                }
            }
        }
    ) { paddingValues ->
        NavHost(
            navController = navController,
            startDestination = "home",
            modifier = Modifier.padding(paddingValues)
        ) {
            composable("home") {
                HomeScreen(
                    viewModel = mainViewModel,
                    onNavigateToContacts = { navController.navigate("contacts") }
                )
            }
            composable("contacts") {
                ContactsScreen(
                    viewModel = mainViewModel,
                    onNavigateBack = { navController.popBackStack() },
                    onContactClick = { contact ->
                        mainViewModel.selectContact(contact)
                        navController.navigate("contact_detail")
                    }
                )
            }
            composable("categories") {
                CategoriesScreen(
                    viewModel = categoryViewModel,
                    onNavigateBack = { navController.popBackStack() }
                )
            }
            composable("settings") {
                SettingsScreen(
                    viewModel = settingsViewModel,
                    onNavigateBack = { navController.popBackStack() }
                )
            }
            composable("contact_detail") {
                ContactDetailScreen(
                    viewModel = mainViewModel,
                    categoryViewModel = categoryViewModel,
                    onNavigateBack = { navController.popBackStack() }
                )
            }
        }
    }
}
