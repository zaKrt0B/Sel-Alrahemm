package com.selrahmak.app.data.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "contacts")
data class ContactEntity(
    @PrimaryKey
    val contactId: String,
    val name: String,
    val phoneNumber: String?,
    val categoryId: String?,
    val importance: Int = 1, // 0 = Very Important, 1 = Important, 2 = Normal
    val notes: String = "",
    val customInterval: Int? = null, // Custom interval in days (null = use category default)
    val lastContactedDate: Long = System.currentTimeMillis(),
    val nextReminderDate: Long = System.currentTimeMillis(),
    val delayDays: Int = 0,
    val pointsEarned: Int = 0,
    val pointsLost: Int = 0,
    val consecutiveContacts: Int = 0,
    val isActive: Boolean = true,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)
