package com.selrahmak.app.data.repository

import android.content.ContentResolver
import android.content.Context
import android.provider.ContactsContract
import com.selrahmak.app.data.database.ContactDao
import com.selrahmak.app.data.database.ContactEntity
import com.selrahmak.app.data.database.ReminderHistoryDao
import com.selrahmak.app.data.database.ReminderHistoryEntity
import kotlinx.coroutines.flow.Flow
import java.util.UUID

class ContactRepository(
    private val contactDao: ContactDao,
    private val reminderHistoryDao: ReminderHistoryDao,
    private val context: Context
) {
    
    fun getAllContacts(): Flow<List<ContactEntity>> = contactDao.getAllContacts()
    
    fun getUncategorizedContacts(): Flow<List<ContactEntity>> = contactDao.getUncategorizedContacts()
    
    fun getContactsByCategory(categoryId: String): Flow<List<ContactEntity>> = 
        contactDao.getContactsByCategory(categoryId)
    
    fun getDelayedContacts(): Flow<List<ContactEntity>> = contactDao.getDelayedContacts()
    
    fun getContactsDueForReminder(currentTime: Long): Flow<List<ContactEntity>> = 
        contactDao.getContactsDueForReminder(currentTime)
    
    suspend fun getContactById(contactId: String): ContactEntity? = 
        contactDao.getContactById(contactId)
    
    fun getContactByIdFlow(contactId: String): Flow<ContactEntity?> = 
        contactDao.getContactByIdFlow(contactId)
    
    fun getTotalPoints(): Flow<Int?> = contactDao.getTotalPoints()
    
    fun getActiveContactCount(): Flow<Int> = contactDao.getActiveContactCount()
    
    fun getDelayedContactCount(): Flow<Int> = contactDao.getDelayedContactCount()
    
    suspend fun insertContact(contact: ContactEntity) = contactDao.insertContact(contact)
    
    suspend fun updateContact(contact: ContactEntity) = contactDao.updateContact(contact)
    
    suspend fun deleteContact(contact: ContactEntity) = contactDao.deleteContact(contact)
    
    suspend fun deactivateContact(contactId: String) = contactDao.deactivateContact(contactId)
    
    suspend fun markAsContacted(contactId: String, actionTaken: String, intervalDays: Int): Result<Unit> {
        return try {
            val currentTime = System.currentTimeMillis()
            val nextReminderDate = currentTime + (intervalDays * 24 * 60 * 60 * 1000L)
            
            // Update contact
            contactDao.markAsContacted(contactId, currentTime, nextReminderDate, currentTime)
            
            // Calculate points
            val contact = contactDao.getContactById(contactId)
            val points = calculatePoints(contact?.consecutiveContacts ?: 0)
            contactDao.addPoints(contactId, points, currentTime)
            
            // Record history
            reminderHistoryDao.insertHistory(
                ReminderHistoryEntity(
                    contactId = contactId,
                    reminderDate = currentTime,
                    actionTaken = actionTaken,
                    pointsEarned = points
                )
            )
            
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
    
    suspend fun snoozeReminder(contactId: String, hours: Int): Result<Unit> {
        return try {
            val contact = contactDao.getContactById(contactId) ?: return Result.failure(Exception("Contact not found"))
            val newReminderDate = System.currentTimeMillis() + (hours * 60 * 60 * 1000L)
            val updatedContact = contact.copy(
                nextReminderDate = newReminderDate,
                updatedAt = System.currentTimeMillis()
            )
            contactDao.updateContact(updatedContact)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
    
    suspend fun importContactsFromDevice(): Result<List<ContactEntity>> {
        return try {
            val contacts = mutableListOf<ContactEntity>()
            val contentResolver: ContentResolver = context.contentResolver
            
            val cursor = contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(
                    ContactsContract.CommonDataKinds.Phone.CONTACT_ID,
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER
                ),
                null,
                null,
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " ASC"
            )
            
            cursor?.use {
                val idColumn = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.CONTACT_ID)
                val nameColumn = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
                val numberColumn = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                
                while (it.moveToNext()) {
                    val id = it.getString(idColumn)
                    val name = it.getString(nameColumn) ?: "Unknown"
                    val number = it.getString(numberColumn)
                    
                    // Check if contact already exists
                    val existingContact = contactDao.getContactById(id)
                    if (existingContact == null) {
                        contacts.add(
                            ContactEntity(
                                contactId = id,
                                name = name,
                                phoneNumber = number,
                                categoryId = null,
                                isActive = false // Don't activate until user categorizes
                            )
                        )
                    }
                }
            }
            
            if (contacts.isNotEmpty()) {
                contactDao.insertContacts(contacts)
            }
            
            Result.success(contacts)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
    
    suspend fun deleteContactFromDevice(contactId: String): Result<Unit> {
        return try {
            val uri = ContactsContract.RawContacts.CONTENT_URI
            val selection = "${ContactsContract.RawContacts.CONTACT_ID} = ?"
            val selectionArgs = arrayOf(contactId)
            context.contentResolver.delete(uri, selection, selectionArgs)
            contactDao.deactivateContact(contactId)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
    
    private fun calculatePoints(consecutiveContacts: Int): Int {
        val basePoints = 10
        val bonusPoints = if (consecutiveContacts > 3) consecutiveContacts * 2 else 0
        return basePoints + bonusPoints
    }
    
    suspend fun updateDelayedContacts() {
        val currentTime = System.currentTimeMillis()
        val contacts = contactDao.getContactsDueForReminder(currentTime)
        
        contacts.collect { contactList ->
            contactList.forEach { contact ->
                val daysPassed = ((currentTime - contact.nextReminderDate) / (24 * 60 * 60 * 1000)).toInt()
                if (daysPassed > 0) {
                    contactDao.updateDelayDays(contact.contactId, daysPassed, currentTime)
                    contactDao.subtractPoints(contact.contactId, daysPassed * 2, currentTime)
                }
            }
        }
    }
}
