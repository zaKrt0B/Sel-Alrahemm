package com.selrahmak.app.data.database

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface CategoryDao {
    
    @Query("SELECT * FROM categories WHERE isActive = 1 ORDER BY isCustom ASC, nameEn ASC")
    fun getAllCategories(): Flow<List<CategoryEntity>>
    
    @Query("SELECT * FROM categories WHERE isCustom = 0 AND isActive = 1")
    fun getDefaultCategories(): Flow<List<CategoryEntity>>
    
    @Query("SELECT * FROM categories WHERE isCustom = 1 AND isActive = 1")
    fun getCustomCategories(): Flow<List<CategoryEntity>>
    
    @Query("SELECT * FROM categories WHERE categoryId = :categoryId")
    suspend fun getCategoryById(categoryId: String): CategoryEntity?
    
    @Query("SELECT * FROM categories WHERE categoryId = :categoryId")
    fun getCategoryByIdFlow(categoryId: String): Flow<CategoryEntity?>
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCategory(category: CategoryEntity)
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCategories(categories: List<CategoryEntity>)
    
    @Update
    suspend fun updateCategory(category: CategoryEntity)
    
    @Delete
    suspend fun deleteCategory(category: CategoryEntity)
    
    @Query("UPDATE categories SET isActive = 0 WHERE categoryId = :categoryId")
    suspend fun deactivateCategory(categoryId: String)
    
    @Query("SELECT COUNT(*) FROM categories WHERE isActive = 1")
    fun getCategoryCount(): Flow<Int>
}
