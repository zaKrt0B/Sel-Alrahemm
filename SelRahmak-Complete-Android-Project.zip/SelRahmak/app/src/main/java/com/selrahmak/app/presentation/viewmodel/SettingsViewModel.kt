package com.selrahmak.app.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.selrahmak.app.util.UserPreferences
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SettingsViewModel(
    private val userPreferences: UserPreferences
) : ViewModel() {
    
    val isSimpleMode = userPreferences.isSimpleMode
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)
    
    val language = userPreferences.language
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "ar")
    
    val theme = userPreferences.theme
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "default")
    
    val defaultWhatsAppMessage = userPreferences.defaultWhatsAppMessage
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "")
    
    val notificationsEnabled = userPreferences.notificationsEnabled
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)
    
    fun setSimpleMode(isSimple: Boolean) {
        viewModelScope.launch {
            userPreferences.setSimpleMode(isSimple)
        }
    }
    
    fun setLanguage(lang: String) {
        viewModelScope.launch {
            userPreferences.setLanguage(lang)
        }
    }
    
    fun setTheme(themeValue: String) {
        viewModelScope.launch {
            userPreferences.setTheme(themeValue)
        }
    }
    
    fun setDefaultWhatsAppMessage(message: String) {
        viewModelScope.launch {
            userPreferences.setDefaultWhatsAppMessage(message)
        }
    }
    
    fun setNotificationsEnabled(enabled: Boolean) {
        viewModelScope.launch {
            userPreferences.setNotificationsEnabled(enabled)
        }
    }
}
