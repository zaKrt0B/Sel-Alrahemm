package com.selrahmak.app.data.repository

import com.selrahmak.app.data.database.CategoryDao
import com.selrahmak.app.data.database.CategoryEntity
import kotlinx.coroutines.flow.Flow

class CategoryRepository(private val categoryDao: CategoryDao) {
    
    fun getAllCategories(): Flow<List<CategoryEntity>> = categoryDao.getAllCategories()
    
    fun getDefaultCategories(): Flow<List<CategoryEntity>> = categoryDao.getDefaultCategories()
    
    fun getCustomCategories(): Flow<List<CategoryEntity>> = categoryDao.getCustomCategories()
    
    suspend fun getCategoryById(categoryId: String): CategoryEntity? = 
        categoryDao.getCategoryById(categoryId)
    
    fun getCategoryByIdFlow(categoryId: String): Flow<CategoryEntity?> = 
        categoryDao.getCategoryByIdFlow(categoryId)
    
    suspend fun insertCategory(category: CategoryEntity) = categoryDao.insertCategory(category)
    
    suspend fun updateCategory(category: CategoryEntity) = categoryDao.updateCategory(category)
    
    suspend fun deleteCategory(category: CategoryEntity) = categoryDao.deleteCategory(category)
    
    suspend fun deactivateCategory(categoryId: String) = categoryDao.deactivateCategory(categoryId)
    
    suspend fun initializeDefaultCategories() {
        val defaultCategories = listOf(
            CategoryEntity(
                categoryId = "cat_parent",
                nameEn = "Parent",
                nameAr = "الوالد / الوالدة",
                defaultIntervalDays = 1,
                isCustom = false
            ),
            CategoryEntity(
                categoryId = "cat_sibling",
                nameEn = "Sibling",
                nameAr = "الأخ / الأخت",
                defaultIntervalDays = 3,
                isCustom = false
            ),
            CategoryEntity(
                categoryId = "cat_uncle_aunt",
                nameEn = "Uncle/Aunt",
                nameAr = "العم / العمة",
                defaultIntervalDays = 7,
                isCustom = false
            ),
            CategoryEntity(
                categoryId = "cat_distant_uncle",
                nameEn = "Distant Uncle/Aunt",
                nameAr = "العم / العمة البعيدين",
                defaultIntervalDays = 30,
                isCustom = false
            ),
            CategoryEntity(
                categoryId = "cat_close_friend",
                nameEn = "Close Friend",
                nameAr = "الصديق المقرب",
                defaultIntervalDays = 5,
                isCustom = false
            ),
            CategoryEntity(
                categoryId = "cat_distant_friend",
                nameEn = "Distant Friend",
                nameAr = "الصديق البعيد",
                defaultIntervalDays = 14,
                isCustom = false
            ),
            CategoryEntity(
                categoryId = "cat_colleague",
                nameEn = "Colleague",
                nameAr = "الزميل",
                defaultIntervalDays = 7,
                isCustom = false
            ),
            CategoryEntity(
                categoryId = "cat_distant_colleague",
                nameEn = "Distant Colleague",
                nameAr = "الزميل البعيد",
                defaultIntervalDays = 21,
                isCustom = false
            ),
            CategoryEntity(
                categoryId = "cat_cousin",
                nameEn = "Cousin",
                nameAr = "ابن العم / ابنة العم / ابن الخال / ابنة الخال",
                defaultIntervalDays = 10,
                isCustom = false
            )
        )
        
        categoryDao.insertCategories(defaultCategories)
    }
}
