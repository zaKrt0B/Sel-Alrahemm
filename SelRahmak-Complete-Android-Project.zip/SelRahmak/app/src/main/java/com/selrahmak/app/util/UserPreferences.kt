package com.selrahmak.app.util

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "settings")

class UserPreferences(private val context: Context) {
    
    companion object {
        val IS_SIMPLE_MODE = booleanPreferencesKey("is_simple_mode")
        val LANGUAGE = stringPreferencesKey("language")
        val THEME = stringPreferencesKey("theme")
        val DEFAULT_WHATSAPP_MESSAGE = stringPreferencesKey("default_whatsapp_message")
        val NOTIFICATIONS_ENABLED = booleanPreferencesKey("notifications_enabled")
        val IS_FIRST_LAUNCH = booleanPreferencesKey("is_first_launch")
    }
    
    val isSimpleMode: Flow<Boolean> = context.dataStore.data.map { preferences ->
        preferences[IS_SIMPLE_MODE] ?: true // Default to simple mode
    }
    
    val language: Flow<String> = context.dataStore.data.map { preferences ->
        preferences[LANGUAGE] ?: "ar" // Default to Arabic
    }
    
    val theme: Flow<String> = context.dataStore.data.map { preferences ->
        preferences[THEME] ?: "default"
    }
    
    val defaultWhatsAppMessage: Flow<String> = context.dataStore.data.map { preferences ->
        preferences[DEFAULT_WHATSAPP_MESSAGE] ?: "كيف حالك؟ أتمنى أن تكون بخير"
    }
    
    val notificationsEnabled: Flow<Boolean> = context.dataStore.data.map { preferences ->
        preferences[NOTIFICATIONS_ENABLED] ?: true
    }
    
    val isFirstLaunch: Flow<Boolean> = context.dataStore.data.map { preferences ->
        preferences[IS_FIRST_LAUNCH] ?: true
    }
    
    suspend fun setSimpleMode(isSimple: Boolean) {
        context.dataStore.edit { preferences ->
            preferences[IS_SIMPLE_MODE] = isSimple
        }
    }
    
    suspend fun setLanguage(lang: String) {
        context.dataStore.edit { preferences ->
            preferences[LANGUAGE] = lang
        }
    }
    
    suspend fun setTheme(themeValue: String) {
        context.dataStore.edit { preferences ->
            preferences[THEME] = themeValue
        }
    }
    
    suspend fun setDefaultWhatsAppMessage(message: String) {
        context.dataStore.edit { preferences ->
            preferences[DEFAULT_WHATSAPP_MESSAGE] = message
        }
    }
    
    suspend fun setNotificationsEnabled(enabled: Boolean) {
        context.dataStore.edit { preferences ->
            preferences[NOTIFICATIONS_ENABLED] = enabled
        }
    }
    
    suspend fun setFirstLaunchComplete() {
        context.dataStore.edit { preferences ->
            preferences[IS_FIRST_LAUNCH] = false
        }
    }
}
