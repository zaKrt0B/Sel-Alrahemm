package com.selrahmak.app.util

import java.text.SimpleDateFormat
import java.util.*

object DateUtils {
    
    fun formatDate(timestamp: Long, locale: Locale = Locale.getDefault()): String {
        val sdf = SimpleDateFormat("dd/MM/yyyy", locale)
        return sdf.format(Date(timestamp))
    }
    
    fun formatDateTime(timestamp: Long, locale: Locale = Locale.getDefault()): String {
        val sdf = SimpleDateFormat("dd/MM/yyyy HH:mm", locale)
        return sdf.format(Date(timestamp))
    }
    
    fun formatRelativeTime(timestamp: Long, context: android.content.Context): String {
        val now = System.currentTimeMillis()
        val diff = now - timestamp
        val days = (diff / (24 * 60 * 60 * 1000)).toInt()
        
        return when {
            days == 0 -> "Today"
            days == 1 -> "Yesterday"
            days < 7 -> "$days days ago"
            days < 30 -> "${days / 7} weeks ago"
            days < 365 -> "${days / 30} months ago"
            else -> "${days / 365} years ago"
        }
    }
    
    fun getDaysSince(timestamp: Long): Int {
        val now = System.currentTimeMillis()
        val diff = now - timestamp
        return (diff / (24 * 60 * 60 * 1000)).toInt()
    }
    
    fun addDays(timestamp: Long, days: Int): Long {
        return timestamp + (days * 24 * 60 * 60 * 1000L)
    }
}
