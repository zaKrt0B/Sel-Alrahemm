package com.selrahmak.app.data.database

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ReminderHistoryDao {
    
    @Query("SELECT * FROM reminder_history ORDER BY createdAt DESC")
    fun getAllHistory(): Flow<List<ReminderHistoryEntity>>
    
    @Query("SELECT * FROM reminder_history WHERE contactId = :contactId ORDER BY createdAt DESC")
    fun getHistoryForContact(contactId: String): Flow<List<ReminderHistoryEntity>>
    
    @Query("SELECT * FROM reminder_history WHERE createdAt >= :startDate ORDER BY createdAt DESC")
    fun getHistorySince(startDate: Long): Flow<List<ReminderHistoryEntity>>
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHistory(history: ReminderHistoryEntity)
    
    @Query("DELETE FROM reminder_history WHERE createdAt < :beforeDate")
    suspend fun deleteOldHistory(beforeDate: Long)
}
