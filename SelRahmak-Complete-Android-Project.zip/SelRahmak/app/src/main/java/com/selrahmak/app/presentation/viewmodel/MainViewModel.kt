package com.selrahmak.app.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.selrahmak.app.data.database.ContactEntity
import com.selrahmak.app.data.repository.ContactRepository
import com.selrahmak.app.util.UserPreferences
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class MainViewModel(
    private val contactRepository: ContactRepository,
    private val userPreferences: UserPreferences
) : ViewModel() {
    
    val allContacts = contactRepository.getAllContacts()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    
    val delayedContacts = contactRepository.getDelayedContacts()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    
    val uncategorizedContacts = contactRepository.getUncategorizedContacts()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    
    val totalPoints = contactRepository.getTotalPoints()
        .map { it ?: 0 }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)
    
    val isSimpleMode = userPreferences.isSimpleMode
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)
    
    val defaultWhatsAppMessage = userPreferences.defaultWhatsAppMessage
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "")
    
    private val _selectedContact = MutableStateFlow<ContactEntity?>(null)
    val selectedContact: StateFlow<ContactEntity?> = _selectedContact
    
    fun selectContact(contact: ContactEntity?) {
        _selectedContact.value = contact
    }
    
    fun markAsContacted(contactId: String, actionTaken: String, intervalDays: Int) {
        viewModelScope.launch {
            contactRepository.markAsContacted(contactId, actionTaken, intervalDays)
        }
    }
    
    fun snoozeReminder(contactId: String, hours: Int) {
        viewModelScope.launch {
            contactRepository.snoozeReminder(contactId, hours)
        }
    }
    
    fun importContacts() {
        viewModelScope.launch {
            contactRepository.importContactsFromDevice()
        }
    }
    
    fun updateContact(contact: ContactEntity) {
        viewModelScope.launch {
            contactRepository.updateContact(contact)
        }
    }
    
    fun deactivateContact(contactId: String) {
        viewModelScope.launch {
            contactRepository.deactivateContact(contactId)
        }
    }
    
    fun deleteContactFromDevice(contactId: String) {
        viewModelScope.launch {
            contactRepository.deleteContactFromDevice(contactId)
        }
    }
}
