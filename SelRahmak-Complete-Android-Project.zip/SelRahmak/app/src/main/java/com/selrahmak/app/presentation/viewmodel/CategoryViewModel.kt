package com.selrahmak.app.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.selrahmak.app.data.database.CategoryEntity
import com.selrahmak.app.data.repository.CategoryRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID

class CategoryViewModel(
    private val categoryRepository: CategoryRepository
) : ViewModel() {
    
    val allCategories = categoryRepository.getAllCategories()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    
    val defaultCategories = categoryRepository.getDefaultCategories()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    
    val customCategories = categoryRepository.getCustomCategories()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    
    fun createCategory(nameEn: String, nameAr: String, intervalDays: Int) {
        viewModelScope.launch {
            val category = CategoryEntity(
                categoryId = UUID.randomUUID().toString(),
                nameEn = nameEn,
                nameAr = nameAr,
                defaultIntervalDays = intervalDays,
                isCustom = true
            )
            categoryRepository.insertCategory(category)
        }
    }
    
    fun updateCategory(category: CategoryEntity) {
        viewModelScope.launch {
            categoryRepository.updateCategory(category)
        }
    }
    
    fun deleteCategory(categoryId: String) {
        viewModelScope.launch {
            categoryRepository.deactivateCategory(categoryId)
        }
    }
    
    fun initializeDefaultCategories() {
        viewModelScope.launch {
            categoryRepository.initializeDefaultCategories()
        }
    }
}
