package com.selrahmak.app.presentation.theme

import androidx.compose.ui.graphics.Color

// Default Theme
val Primary = Color(0xFF40513B)
val PrimaryDark = Color(0xFF2F3E2C)
val Secondary = Color(0xFF628141)
val Background = Color(0xFFE5D9B6)
val Surface = Color(0xFFFFFFFF)
val Alert = Color(0xFFE67E22)
val Error = Color(0xFFD32F2F)
val OnPrimary = Color(0xFFFFFFFF)
val OnSecondary = Color(0xFFFFFFFF)
val OnBackground = Color(0xFF1C1B1F)
val OnSurface = Color(0xFF1C1B1F)
val OnError = Color(0xFFFFFFFF)

// Additional Colors
val Success = Color(0xFF4CAF50)
val Warning = Color(0xFFFFC107)
val Info = Color(0xFF2196F3)
val TextPrimary = Color(0xFF212121)
val TextSecondary = Color(0xFF757575)
val Divider = Color(0xFFBDBDBD)
